@echo off
java -jar piratas.jar
pause